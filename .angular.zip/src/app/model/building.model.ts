import { NumberSymbol } from "@angular/common"

export class Building
{
  building_id?:number
  building_name?:string
  location?:string
  status?:string
  no_of_floors?:number

}
