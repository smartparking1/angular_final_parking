


export class Login{
  constructor(
    public email_id:string,
    public password:string,
  ){}
}

export class User{
  id?:number;
  name?:string;
  email?:string;
  contact?:number;
  password?: string;
  cpassword?:string;
  role?:string;


}
