export class Slots{
  constructor(
    public slot_id?:number,
    public slot_name?:string,
    public status?:string,
    public floor_id?:number,
  ){}
}
