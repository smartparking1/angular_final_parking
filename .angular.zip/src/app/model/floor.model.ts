import { Building } from 'src/app/model/building.model';
export class Floor
{
  public floor_id?:number
  public floor_no?:string
  public no_of_slots?:number
  public status?:string
  public building?:Building
  public location?:string

}
