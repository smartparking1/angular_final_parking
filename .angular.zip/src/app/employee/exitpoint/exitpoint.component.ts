import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exitpoint',
  templateUrl: './exitpoint.component.html',
  styleUrls: ['./exitpoint.component.css']
})
export class ExitpointComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
