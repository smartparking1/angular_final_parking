import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-homepage',
  templateUrl: './employee-homepage.component.html',
  styleUrls: ['./employee-homepage.component.css']
})
export class EmployeeHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
