import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-finepage',
  templateUrl: './finepage.component.html',
  styleUrls: ['./finepage.component.css']
})
export class FinepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
