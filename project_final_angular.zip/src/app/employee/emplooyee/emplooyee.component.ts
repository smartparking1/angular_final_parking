import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emplooyee',
  template:'<router-outlet></router-outlet>'
})
export class EmplooyeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
