


export class Login{
  constructor(
    public email_id:string,
    public password:string,
  ){}
}

