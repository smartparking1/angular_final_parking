export class User{

  id?:number;
  employee_name?:string;
  role?:string;
  mobile_number?:number;
  email_id?: string;
  password?:string;
  // cpassword?:string;
  location?:string;
  image?:string;


}
