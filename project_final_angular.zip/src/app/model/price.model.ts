import { Building } from "./building.model"

export class Price {
  public id?:number;
  public building?:number;
  public day_type?:string;
  public vehicle_type?:string;
  public price?:number
}
